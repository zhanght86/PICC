一，telnet_message.txt
    将需要测试的ip和端口放在此文件中
    格式：10.10.68.241 8001

二，telnet.sh
    遍历telnet_messgae.txt中的内容进行telnet，将结果保存到telnet_ok.txt和telnet_fail.txt中。